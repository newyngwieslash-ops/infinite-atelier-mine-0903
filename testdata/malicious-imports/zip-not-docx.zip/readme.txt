an ordinary archive that merely resembles a docx
